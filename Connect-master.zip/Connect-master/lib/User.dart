

class UserDetails {

  String emailid;
  String type;
  dynamic latitude;
  dynamic longitude;
  bool emailVerified;
  UserDetails(this.emailid,this.type,this.latitude,this.longitude,this.emailVerified);

}
