

Connect : An Application to connect shopkeepers to their customers. It is built to help the customers discover local shops and order items from them.

