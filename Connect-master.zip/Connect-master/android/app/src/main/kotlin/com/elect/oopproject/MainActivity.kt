package com.elect.oopproject

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
